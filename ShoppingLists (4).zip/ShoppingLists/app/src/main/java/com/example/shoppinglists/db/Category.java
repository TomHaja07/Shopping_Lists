package com.example.shoppinglists.db;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/* Databáze - přidávání kategorií pro nákupní seznamy */

@Entity
public class Category {

        @PrimaryKey(autoGenerate = true)
        public int uid;

        @ColumnInfo(name = "categoryName")
        public String categoryName;

}
